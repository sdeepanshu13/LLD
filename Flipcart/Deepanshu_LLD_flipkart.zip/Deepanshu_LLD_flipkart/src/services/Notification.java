package services;

public class Notification {
    public void sendNotification(String recepient, String message){
        System.out.println("Notification to "+ recepient+": "+ message );
    }
}
