
import services.FoodOrderingSystem;
import strategies.LowestPriceStrategy;

import models.*;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        try {
            // Create the food ordering system
            FoodOrderingSystem system = new FoodOrderingSystem(new LowestPriceStrategy());

            // Onboard new restaurants
            try {
                system.addRestaurant("A2B", Map.of("Idly", 40, "Vada", 30, "Dosa", 50), 4);
                system.addRestaurant("Rasaganga", Map.of("Idly", 45, "Poori", 25, "Set Dosa", 60), 6);
                system.addRestaurant("Eat Fit", Map.of("Idly", 30, "Vada", 40), 2);

                System.out.println((system.getRestaurant("A2B").getMenu()) + "  Capacity: " + system.getRestaurant("A2B").getMaxCapacity());
                System.out.println();
                System.out.println((system.getRestaurant("Rasaganga").getMenu()) + " Capacity: " + system.getRestaurant("Rasaganga").getMaxCapacity());
                System.out.println();
                System.out.println((system.getRestaurant("Eat Fit").getMenu()) + " Capacity: " + system.getRestaurant("Eat Fit").getMaxCapacity());
                System.out.println();

                Order order1 = system.placeOrder(List.of("Idly", "Poori"));
                System.out.println("Order ID#: " + order1.getOrderId() + ": Ordered from " + order1.getRestaurant().getName());

                // Get the UUID of the order
                String orderId1 = order1.getOrderId();
                System.out.println("UUID of Order 1: " + orderId1);

                // Place another order
                Order order2 = system.placeOrder(List.of("Idly", "Vada"));
                System.out.println("Order ID#: " + order2.getOrderId() + ": Ordered from " + order2.getRestaurant().getName());

                // Get the UUID of the second order
                String orderId2 = order2.getOrderId();
                System.out.println("UUID of Order 2: " + orderId2);

                // Check system stats
                System.out.println(system.getSystemStats());

                // Try placing an order when capacity is not sufficient
                Order order3 = system.placeOrder(List.of("Idly"));
                String orderId3 = order3.getOrderId();
                System.out.println("Order ID#: " + order3.getOrderId() + ": Ordered from " + order3.getRestaurant().getName());
                System.out.println("UUID of Order 3: " + orderId3);



                system.fulfillOrder(orderId1);  // Fulfill the order via the system
                System.out.println("Order ID: #" + orderId1 + " has been fulfilled.");
                System.out.println(system.getSystemStats());

                system.fulfillOrder(orderId2);  // Fulfill the order via the system
                System.out.println("Order ID: #" + orderId2 + " has been fulfilled.");

                System.out.println("Max capacity of A2B: " + system.getRestaurant("A2B").getMaxCapacity());

                system.changeMenu("Eat Fit", Map.of("Idly", 60, "Vada", 50, "Dosa", 70));
                System.out.println("Menu updated for Eat Fit!");

                // Display the new menu for Eat Fit
                System.out.println(system.getRestaurant("Eat Fit").getMenu());
                System.out.println();

               System.out.println( system.getOrderById(orderId1).getRestaurant().getName());

                System.out.println();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }

            // Try placing an order again after the menu update
            try {
                Order updatedOrder = system.placeOrder(List.of("Idly"));
                System.out.println("Order ID#" + updatedOrder.getOrderId() + ": Ordered from " + updatedOrder.getRestaurant().getName());
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

/*

--Onboard new restaurant with its menu and item processing capacity. The menu should be reflected in the food ordering system.
--A restaurant should be able to change its menu.
--Customers should be able to place an order by giving items. We can assume that each item will be of only 1 quantity.
--Implement one restaurant selection strategy (lowest price offered by the restaurant for that item.) Have the option of selection using a different strategy.
--System should be able to keep track of all items served by each restaurant, and the system should be aware of the remaining capacity of each restaurant at a given time.
--Once the order is fulfilled by the restaurant, the capacity should be replenished for the given restaurant.

 */