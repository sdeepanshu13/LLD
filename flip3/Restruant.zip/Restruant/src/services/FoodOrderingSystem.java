package services;

import exceptions.OrderProcessingException;
import models.*;
import strategies.OrderStrategy;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class FoodOrderingSystem {
    private final List<Restaurant> restaurants;
    private final Map<String, Order> orderHistory; // To track orders by order ID
    private final OrderStrategy orderStrategy;

    public FoodOrderingSystem(OrderStrategy orderStrategy) {
        this.restaurants = new CopyOnWriteArrayList<>(); // Concurrent list
        this.orderHistory = new HashMap<>(); // Map to track orders
        this.orderStrategy = orderStrategy;
    }

    // Add a new restaurant to the system
    public void addRestaurant(String name, Map<String, Integer> menu, int maxCapacity) {
        restaurants.add(new RestaurantImpl(name, menu, maxCapacity));
    }

    // Change the menu of an existing restaurant
    public void changeMenu(String restaurantName, Map<String, Integer> newMenu) throws OrderProcessingException {
        Restaurant restaurant = findRestaurantByName(restaurantName);
        restaurant.setMenu(newMenu);
    }

    // Place an order by selecting restaurants and items
    public Order placeOrder(List<String> items) throws OrderProcessingException {

    Map<Restaurant, List<String>> allocation = orderStrategy.selectRestaurants(items, restaurants);

    if (allocation.isEmpty()) {
        throw new OrderProcessingException("Order cannot be fulfilled due to insufficient capacity or unavailable items.");
    }

    String orderId = UUID.randomUUID().toString();
    List<Restaurant> restaurantsUsed = new ArrayList<>();

    for (Map.Entry<Restaurant, List<String>> entry : allocation.entrySet()) {
        Restaurant restaurant = entry.getKey();
        int orderSize = entry.getValue().size();

        // Validate restaurant capacity
        if (restaurant.getCurrentCapacity() >= orderSize) {
            restaurant.reduceCapacity(orderSize);  // Reduce capacity by the order size
            restaurantsUsed.add(restaurant); // Track which restaurants are used
        } else {
            throw new OrderProcessingException("Restaurant " + restaurant.getName() + " does not have enough capacity.");
        }

        Order order = new OrderImpl(orderId, entry.getKey(), entry.getValue());  // Corrected constructor usage
        orderHistory.put(orderId, order);
    }

    // Create and return a summary of the order placement
    StringBuilder response = new StringBuilder("Order placed using: ");
    restaurantsUsed.forEach(restaurant -> response.append(restaurant.getName()).append(", "));

    return new OrderImpl(orderId, allocation.keySet().iterator().next(), items); // Corrected constructor
}


    // Fulfill an order and replenish restaurant capacity
    public void fulfillOrder(String orderId) throws OrderProcessingException {
        // Retrieve the order by its ID
        Order order = orderHistory.get(orderId);
        if (order == null) {
            throw new OrderProcessingException("Order not found: " + orderId);
        }

        // Replenish capacity for the specific restaurant
        Restaurant restaurant = order.getRestaurant();
        restaurant.replenishCapacity(order.getItems().size());
        // Mark order as fulfilled (if applicable)
        order.fulfill();
    }

    // Get system stats on available capacity for each restaurant
    public String getSystemStats() {
        StringBuilder stats = new StringBuilder();
        for (Restaurant restaurant : restaurants) {
            stats.append(restaurant.getName())
                 .append(": ")
                 .append(restaurant.getCurrentCapacity())
                 .append(" items available\n");
        }
        return stats.toString();
    }

    // Helper method to find a restaurant by its name
    private Restaurant findRestaurantByName(String name) throws OrderProcessingException {
        for (Restaurant restaurant : restaurants) {
            if (restaurant.getName().equals(name)) {
                return restaurant;
            }
        }
        throw new OrderProcessingException("Restaurant not found: " + name);
    }

    // Getter method to retrieve a restaurant by its name
    public Restaurant getRestaurant(String name) throws OrderProcessingException {
        return findRestaurantByName(name);
    }

    // Method to get an order by its ID (using String)
    public Order getOrderById(String orderId) throws OrderProcessingException {
        Order order = orderHistory.get(orderId);
        if (order == null) {
            throw new OrderProcessingException("Order not found: " + orderId);
        }
        return orderHistory.get(orderId);
    }
}
