package models;

import java.util.List;

public interface Order {
    String getOrderId();
    Restaurant getRestaurant();
    List<String> getItems();
    boolean isFulfilled();
    void fulfill();
}