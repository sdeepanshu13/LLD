package models;

import java.util.Map;

public interface Restaurant {
    String getName();

    Map<String, Integer> getMenu();

    void setMenu(Map<String, Integer> menu);

    int getMaxCapacity();

    int getCurrentCapacity();

    void reduceCapacity(int items);

    void replenishCapacity(int items);


}
