package models;

import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class RestaurantImpl implements Restaurant {
    private final String name;
    private Map<String, Integer> menu;
    private final int maxCapacity;
    private int currentCapacity;

    public RestaurantImpl(String name, Map<String, Integer> menu, int maxCapacity) {
        this.name = name;
        this.menu = new ConcurrentHashMap<>(menu); // Initialize with ConcurrentHashMap
        this.maxCapacity = maxCapacity;
        this.currentCapacity = maxCapacity;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Map<String, Integer> getMenu() {
        return menu;
    }

    @Override
    public void setMenu(Map<String, Integer> menu) {
        this.menu = new ConcurrentHashMap<>(menu); // Set menu with thread-safe map
    }

    @Override
    public int getMaxCapacity() {
        return maxCapacity;
    }

    @Override
    public int getCurrentCapacity() {
        return currentCapacity;
    }

    @Override
    public void reduceCapacity(int items) {
        currentCapacity -= items;
    }

    @Override
    public void replenishCapacity(int items) {
        currentCapacity += items;
    }


}
