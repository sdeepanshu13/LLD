package models;

import models.Order;

import java.util.List;

public class OrderImpl implements Order {
    private final String orderId;
    private final Restaurant restaurant;
    private final List<String> items;
    private boolean isFulfilled;

    // Constructor
    public OrderImpl(String orderId, Restaurant restaurant, List<String> items) {
        this.orderId = orderId;
        this.restaurant = restaurant;
        this.items = items;
        this.isFulfilled = false;
    }

    @Override
    public String getOrderId() {
        return orderId;
    }

    @Override
    public Restaurant getRestaurant() {
        return restaurant;
    }

    @Override
    public List<String> getItems() {
        return items;
    }

    @Override
    public boolean isFulfilled() {
        return isFulfilled;
    }

    @Override
    public void fulfill() {
        this.isFulfilled = true;
    }
}
