package interfaces;

public interface CutomerInterface {
    String getName();
    String getEmail();
    String getPhoneNumber();
    String getAddress();
}
