package interfaces;

public interface DriverInterface {
    String getName();
    boolean isAvailable();
    Integer getRating();

}
