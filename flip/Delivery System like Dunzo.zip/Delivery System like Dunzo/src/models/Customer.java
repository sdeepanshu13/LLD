package models;

import interfaces.CutomerInterface;

public class Customer  implements CutomerInterface {
    private final String name;
    private final String email;
    private final String phoneNumber;
    private final String address;

    public Customer(String name, String email, String phoneNumber, String address) {
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }
}
