import models.ParcelDeliveryService;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/*
i: onboard customer -> tom, aa@gmail.com, 123456789 , address1
o: welcome tom!
i: onboard customer -> paul, bb@gmail.com, 987654321 , address2
o: welcome paul!
i: onboard driver-> driver1
o: welcome driver1!
i: driver status -> driver1
o: idle
i: Place order -> from:tom, item1, to:paul
o: order is placed. Order id : order123
n: to tom -> order is placed by you Order id : order123
n: to paul -> order is placed for you Order id : order123
n: to driver1 -> order123 is assigned to you.
n: to tom, paul -> order is assigned to a driver, driver details : driver1
i: order pickup -> driver1, order123
o: order123 is picked up by the driver1.
n: to tom,paul -> order123 is picked up by the driver1.
i: order status -> order123
o: order details -> order is in transit. Driver details: driver1.
i: Place order -> from:paul, item2, to:tom
o: order is placed. Order id : order124
n: to paul -> order is placed by you Order id : order124
n: to tom -> order is placed for you Order id : order124
i: order status -> order124
o: order 124 is created. Waiting for driver availability.
i: onboard driver-> driver2
o: welcome driver2!
n: to driver2 -> order124 is assigned to you.
n: to tom, paul -> order124 is assigned to a driver, driver details : driver1

After 60 seconds of order124 creation
n: to tom, paul -> order124 is canceled due to driver unavailability. 
i: order pickup -> driver2, order124
o: order cannot be picked up. Order124 is canceled.
i: order delivered -> driver1, order123


 */
public class Main {
    public static void main(String[] args) throws InterruptedException {
     

            ParcelDeliveryService service = new ParcelDeliveryService();

            service.onboardCustomer("John", "john@gmail.com", "1234", "123 street");
            service.onboardCustomer("Harry", "harry@gmail.com", "98765", "9876 street");

            service.onboardDriver("Bob");
            service.onboardDriver("Alice");

            service.placeOrder("john@gmail.com", "Pizza", "123 street", "1");
            service.placeOrder("harry@gmail.com", "Burger", "9876  street", "2");

            TimeUnit.SECONDS.sleep(2);
            service.pickUpOrder("Alice", "2");
            service.pickUpOrder("Bob", "1");

            service.deliverOrder("Alice", "1");
            service.deliverOrder("Bob", "2");

            service.getOrderStatus("1");
            service.getDriverStatus("Bob");

            service.cancelOrder("1");
            service.getOrderStatus("1");
        

        }
    }