package interfaces;

public interface CustomerInterface {
    String getName();
    String getEmail();
    String getPhoneNumber();
    String getAddress();
}
